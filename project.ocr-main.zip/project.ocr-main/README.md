# project.ocr
ocr 광학문자인식 프로젝트 포트폴리오 사이트
